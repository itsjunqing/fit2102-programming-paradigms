# lecture8
cd into the directory, then:
```
$ stack build
$ stack exec doctest src/Callcentre.hs
```