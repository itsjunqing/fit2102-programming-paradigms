import Test.DocTest (doctest)

main :: IO ()
main = doctest ["src/Callcentre.hs"]
